import 'package:dashboard/common/widgets/containers/rounded_container.dart';
import 'package:dashboard/utils/constants/sizes.dart';
import 'package:dashboard/utils/validators/validation.dart';
import 'package:flutter/material.dart';

// Assuming you already have these utilities in your project
// import 'package:your_app/utils/t_sizes.dart';
// import 'package:your_app/utils/t_validator.dart';
// import 'package:your_app/widgets/t_rounded_container.dart';

class ProductTitleAndDescription extends StatelessWidget {
  const ProductTitleAndDescription({super.key});

  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      child: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 Section Title
            Text(
              'Basic Information',
              style: Theme.of(context).textTheme.headlineSmall,
            ),

            const SizedBox(height: TSizes.spaceBtwItems),

            // 🔹 Product Title Input Field
            TextFormField(
              validator:
                  (value) =>
                      TValidator.validateEmptyText('Product Title', value),
              decoration: const InputDecoration(labelText: 'Product Title'),
            ),

            const SizedBox(height: TSizes.spaceBtwInputFields),

            // 🔹 Product Description Input Field
            SizedBox(
              height: 388,
              child: TextFormField(
                expands: true,
                maxLines: null,
                textAlign: TextAlign.start,
                keyboardType: TextInputType.multiline,
                textAlignVertical: TextAlignVertical.top,
                validator:
                    (value) => TValidator.validateEmptyText(
                      'Product Description',
                      value,
                    ),
                decoration: const InputDecoration(
                  labelText: 'Product Description',
                  hintText: 'Add your Product Description here...',
                  alignLabelWithHint: true,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
